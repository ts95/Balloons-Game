

Download the code from this url:

http://download.savannah.gnu.org/releases/freetype/freetype-2.5.0.1.tar.gz

Copy the src folder from freetype-2.5.0.1 folder to this directory